import EventEmitter from "node:events";
import WebSocket from "ws";

const REQUEST = "REQUEST";
export const isActive = value => value === true || value === 1 || value === 'true' || value === '1';

export class UlanziProtocolClient extends EventEmitter {
  constructor({ WebSocketImpl = WebSocket, timerApi = globalThis } = {}) {
    super();
    this.WebSocketImpl = WebSocketImpl;
    this.websocket = null;
    this.uuid = "";
    this.key = "";
    this.actionid = "";
    this.timerApi=timerApi;this.retry=null;this.stopping=false;
  }

  connect(uuid, port = 3906, address = "127.0.0.1") {
    this.stopping=false;
    const [argvAddress, argvPort] = process.argv.slice(2);
    this.uuid = uuid;
    this.address = argvAddress || address;
    this.port = argvPort || port;
    this.websocket = new this.WebSocketImpl(`ws://${this.address}:${this.port}`);
    this.websocket.on("open", () => {
      this.websocket.send(JSON.stringify({ code: 0, cmd: "connected", uuid: this.uuid }));
      this.emit("connected", {});
    });
    this.websocket.on("error", () => this.emit("error", {}));
    this.websocket.on("close", () => {
      this.emit("close", {});
      if(!this.stopping&&!this.retry)this.retry=this.timerApi.setTimeout(()=>{this.retry=null;this.key='';this.actionid='';this.connect(uuid,port,address);},1500);
    });
    this.websocket.on("message", (payload) => this.receive(payload));
  }

  receive(payload) {
    let data;
    try { data = JSON.parse(String(payload)); }
    catch { this.emit("error", {}); return; }
    if (!data || (data.code !== undefined && data.cmdType !== REQUEST)) return;
    if (!this.key && data.uuid === this.uuid && data.key) this.key = data.key;
    if (!this.actionid && data.uuid === this.uuid && data.actionid) this.actionid = data.actionid;
    if (this.uuid.split(".").length === 4) this.send(data.cmd, { code: 0, ...data });

    if (data.cmd === "clear") {
      const contexts = Array.isArray(data.param)
        ? data.param.map((item) => this.encodeContext(item))
        : [];
      this.emit("clear", contexts);
      return;
    }
    data.context = this.encodeContext(data);
    if (data.cmd === "setActive" || data.cmd === "setactive") data.active = isActive(data.active ?? data.param?.active);
    this.emit(data.cmd, data);
  }

  encodeContext(data) { return `${data.uuid}___${data.key}___${data.actionid}`; }
  decodeContext(context) {
    const [uuid, key, actionid] = String(context).split("___");
    if (!uuid || !key || !actionid) throw new Error("Invalid action context");
    return { uuid, key, actionid };
  }
  send(cmd, params) {
    if (this.websocket?.readyState !== this.WebSocketImpl.OPEN) return false;
    this.websocket.send(JSON.stringify({ cmd, uuid: this.uuid, key: this.key, actionid: this.actionid, ...params }));
    return true;
  }
  setBaseDataIcon(context, data, text = "") {
    const { uuid, key, actionid } = this.decodeContext(context);
    const sent = this.send("state", { uuid, key, actionid, param: { statelist: [{ uuid, key, actionid, type: 1, data, textData: text, showtext: Boolean(text) }] } });
    if (!sent) throw new Error("WebSocket is not open");
  }
  setGifDataIcon(context, gifdata, text = "") {
    return this.setGifIcon(context, 3, "gifdata", gifdata, text);
  }
  setGifPathIcon(context, gifpath, text = "") {
    if (typeof gifpath !== "string" || gifpath.includes("..") || gifpath.includes(":") || gifpath.startsWith("\\")) throw new Error("GIF path must be plugin-relative");
    return this.setGifIcon(context, 4, "gifpath", gifpath, text);
  }
  setGifIcon(context, type, field, value, text) {
    const { uuid, key, actionid } = this.decodeContext(context);
    const sent = this.send("state", { uuid, key, actionid, param: { statelist: [{ uuid, key, actionid, type, [field]: value, textData: text, showtext: Boolean(text) }] } });
    if (!sent) throw new Error("WebSocket is not open");
  }
  canSendFrame(bytes, budget = 1024 * 1024) {
    return this.websocket?.readyState === this.WebSocketImpl.OPEN && this.websocket.bufferedAmount + bytes <= budget;
  }
  getGlobalSettings(context) {
    const { uuid, key, actionid } = this.decodeContext(context);
    return this.send("getGlobalSettings", { uuid, key, actionid });
  }
  setGlobalSettings(settings, context) {
    const { uuid, key, actionid } = this.decodeContext(context);
    return this.send("setGlobalSettings", { uuid, key, actionid, settings });
  }
  setSettings(settings, context) {
    const { uuid, key, actionid } = this.decodeContext(context);
    return this.send("setSettings", { uuid, key, actionid, settings });
  }
  sendToPropertyInspector(payload, context) {
    const { uuid, key, actionid } = this.decodeContext(context);
    return this.send("sendToPropertyInspector", { uuid, key, actionid, payload });
  }
  onConnected(handler) { this.on("connected", handler); return this; }
  onAdd(handler) { this.on("add", handler); return this; }
  onRun(handler) { this.on("run", handler); return this; }
  onSetActive(handler) { this.on("setActive", handler); return this; }
  onSetactive(handler) { this.on("setactive", handler); return this; }
  onSendToPlugin(handler) { this.on("sendToPlugin", handler); return this; }
  onParamFromPlugin(handler) { this.on("paramfromplugin", handler); return this; }
  onDidReceiveSettings(handler) { this.on("didReceiveSettings", handler); return this; }
  onDidReceiveGlobalSettings(handler) { this.on("didReceiveGlobalSettings", handler); return this; }
  toast(message) { return this.send("toast", { msg: String(message).slice(0, 160) }); }
  onClear(handler) { this.on("clear", handler); return this; }
  onClose(handler) { this.on("close", handler); return this; }
  onError(handler) { this.on("error", handler); return this; }
  close() { this.stopping=true;if(this.retry)this.timerApi.clearTimeout(this.retry);this.retry=null;this.websocket?.close(); }
}
